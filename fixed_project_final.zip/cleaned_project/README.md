# Marketplace Shop Management System

A JavaFX desktop application for managing an e-commerce marketplace, built with Java 17, JavaFX, and MySQL.

## Prerequisites

- **Java 17** (JDK 17+)
- **Maven 3.8+**
- **MySQL 8.0+**

## Database Setup

1. Open MySQL and create the database:
   ```sql
   CREATE DATABASE marketplace;
   USE marketplace;
   ```

2. Run the SQL script provided in `sql/schema.sql` to create all tables.

3. Insert a test employee and credentials:
   ```sql
   INSERT INTO statuses (statuse_code, statuse_name) VALUES ('ACTIVE', 'Active');
   INSERT INTO department (department_name, statuse_code_fk, city) VALUES ('IT', 'ACTIVE', 'Main City');
   INSERT INTO users (user_name, user_email, statuse_code_fk, department_id_fk) VALUES ('Admin', 'admin@shop.com', 'ACTIVE', 1);
   INSERT INTO user_credentials (user_id_fk, password_hash) VALUES (1, 'admin123');
   INSERT INTO products_statuse (product_statuse_code, state) VALUES ('AVL', 'Available');
   INSERT INTO order_statuse (order_statuse_code, state) VALUES ('NEW', 'New');
   ```

## Database Connection

The app connects to MySQL with:
- **URL:** `jdbc:mysql://localhost:3306/marketplace`
- **User:** `root`
- **Password:** `158243101`

Edit `DatabaseConnection.java` if your settings differ.

## Running

```bash
mvn clean javafx:run
```

## Login

Use the email and password you inserted in the test data step:
- Email: `admin@shop.com`
- Password: `admin123`

## Project Structure

```
src/main/java/com/marketplace/shop/
├── App.java                    # Application entry point
├── model/                      # 22 OOP classes (one per table)
│   ├── Status.java
│   ├── Permission.java
│   ├── Department.java
│   ├── User.java               # = Employee
│   ├── Customer.java
│   ├── Product.java
│   ├── Order.java
│   └── ... (15 more)
├── dao/                        # Data Access Objects (CRUD)
│   ├── GenericDAO.java         # Interface
│   ├── UserDAO.java
│   ├── ProductDAO.java
│   └── ...
├── controller/                 # JavaFX controllers
│   ├── LoginController.java
│   ├── DashboardController.java
│   ├── ProductsController.java
│   └── ...
└── util/                       # Helpers
    ├── DatabaseConnection.java
    ├── AlertHelper.java
    └── SessionManager.java

src/main/resources/
├── fxml/                       # FXML layouts
└── css/style.css               # Stylesheet
```

## Features

- Employee login authentication
- Product CRUD with search
- Customer CRUD with search
- Order viewing
- Payment tracking
- Category management
- Employee directory
- Clean, native-looking UI
